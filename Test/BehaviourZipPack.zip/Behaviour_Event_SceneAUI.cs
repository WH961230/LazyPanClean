﻿using LazyPanClean;
using UnityEngine.UI;

namespace LazyPan {
    public class Behaviour_Event_SceneAUI : LPBehaviour {
        public Behaviour_Event_SceneAUI(LPEntity entity, string behaviourSign) : base(entity, behaviourSign) {
            LPFlo.Instance.GetFlow(out Flow_SceneA flow);
            Button jumpBtn = LPCond.Instance.Get<Button>(flow.GetUI(), LPLabel.JUMP);
            LPButtonRegister.AddListener(jumpBtn, () => {
                flow.Next("SceneB");
            });
        }

        public override void DelayedExecute() {
            
        }

        public override void Clear() {
            base.Clear();
        }
    }
}