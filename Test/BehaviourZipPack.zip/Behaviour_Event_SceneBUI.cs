﻿using LazyPanClean;
using UnityEngine.UI;

namespace LazyPan {
    public class Behaviour_Event_SceneBUI : LPBehaviour {
        public Behaviour_Event_SceneBUI(LPEntity entity, string behaviourSign) : base(entity, behaviourSign) {
            LPFlo.Instance.GetFlow(out Flow_SceneB flow);
            Button jumpBtn = LPCond.Instance.Get<Button>(flow.GetUI(), LPLabel.JUMP);
            LPButtonRegister.AddListener(jumpBtn, () => {
                flow.Next("SceneA");
            });
        }

        public override void DelayedExecute() {
            
        }

        public override void Clear() {
            base.Clear();
        }
    }
}